const express = require("express");
const app = express();
const cors = require("cors");
app.use(cors());
const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
require("dotenv").config();


//before using router make sure you declared bodyParser priot to that
//otherwise requested data wont come to under server req.body object
const router = require("./routers");
app.use(router);
app.use(express.urlencoded({ extended: false }));
app.disable("etag");

app.listen("4000", () => {
  console.log("Back-End Running at port 4000");
});
