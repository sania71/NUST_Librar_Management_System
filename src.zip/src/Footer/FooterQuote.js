import React from "react";
import "./FooterDesign.css";

function FooterQuote() {
  return (
    <div className="container-fluid footerAbout">
      <div className="row p-3 text-center justify-content-center">
        NUST  offers a library for their students and management of these
        books will be tracked using this site
      </div>
    </div>
  );
}

export default FooterQuote;
